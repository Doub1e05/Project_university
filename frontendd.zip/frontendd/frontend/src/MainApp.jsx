import React, { useState, useEffect } from 'react';
import ReactDOM from 'react-dom/client';
import { BrowserRouter } from 'react-router-dom';
import Cookies from 'js-cookie';

import App from './App.jsx';
import AuthApp from './AuthApp.jsx';
import './index.css';

const user = {
  name: 'Иванов И.И.',
  role: 'студент',
  
};

const MainApp = () => {

  return (
    <React.StrictMode>
        
    </React.StrictMode>
  );
};

export default MainApp; // Экспортируем MainApp как значение по умолчанию

ReactDOM.createRoot(document.getElementById('root')).render(
  <MainApp />
);
