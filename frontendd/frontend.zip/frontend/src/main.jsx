import React from 'react'
import ReactDOM from 'react-dom/client'
import { BrowserRouter, redirect } from 'react-router-dom'

import App from './App.jsx'
import './index.css'

const user = {
  name: 'Пахарева И.  В.',
  role: 'преподаватель',
  // another db data
}

const login = true

ReactDOM.createRoot(document.getElementById('root')).render(
  <React.StrictMode>
    <BrowserRouter>
    {login && <App user={user} />}
    </BrowserRouter>
  </React.StrictMode>
)
