export default function InProc() {
  return (
    <>
      <h1>В РАЗРАБОТКЕ ))</h1>
    
    </>
  )
}